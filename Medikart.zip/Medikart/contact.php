<html>
<head>
    <title>Contact us l</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container" style="margin-top: 20px;">

    <center><h2 style="font-family:Times New Roman;">Contact Us:-</h2></center>

                   <div style="margin-top: 20px;  font-size: 25px; font-family:Times New Roman;"> 
                     
                    Address  :- Medikart, Near Bus Depot, Mangaon(402104).
                <br>              

                                   
                    Email    :-medikart.mangaon@gmail.com
                <br>
                

                    Mobile no. :-9988776655
</div>
              
              
               
                
    
  
        <h3 style="margin-top: 50px;">Submit feedback</h3>
        <form action="form-process.php" method="POST">
            <div class="form-group">
                <label for="firstname">Firstname</label>
                <input type="text" name="firstname" id="firstname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="lastname">Lastname</label>
                <input type="text" name="lastname" id="lastname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="tel" name="phone" id="phone" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="message">Message</label>
                <input type="text" name="message" id="message" class="form-control" required>
            </div>
            <div class="form-group">
        <button class="btn btn-success" type="submit">Submit</button>
        <button class="btn btn-danger" type="reset">Reset</button>
    </div>
        </form>
    </div>
</body>

</html>