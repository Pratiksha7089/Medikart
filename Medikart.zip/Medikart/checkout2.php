<html>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<style>
.row {
  display: -ms-flexbox; 
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; 
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; 
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; 
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #04AA6D;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}


@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}

</style>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.2.3/jquery.payment.min.js"></script>


<script type="text/javascript" src="https://js.stripe.com/v2/"></script>

<body>
    <div class="row">
    <div class="col-75">
        <div class="container">

        <form action="checkout.php" method="post">

            <div class="row">
            <div class="col-50">
                <h3>Billing Address</h3>
                <label for="name"><i class="fa fa-user"></i> 
                   Full Name
                </label>
                <input type="text" id="name" name="name" placeholder="X Y Z">

                <label for="email"><i class="fa fa-envelope"></i>                     
                    Email
                </label>
                <input type="text" id="email" name="email" placeholder="medikart@gmail.com">

                <label for="mobile"><i class="fa fa-mobile"></i>                   
                  Mobile no.
              </label>
              <input type="text" id="mobile" name="mobile" placeholder="9988776655">
                
                <label for="adr"><i class="fa fa-address-card-o"></i>                    
                    Address
                </label>
                <input type="text" id="adr" name="address" placeholder="">
                
             
               
                <label for="amount"><i class="fa fa-money"></i>                    
                    Total Amount
                </label>
                <input type="text" id="amount" name="amount" value="<?php echo $_REQUEST['price']?>" >
                
                
                <label for="products"><i class="fa fa-medicine"></i>                    
                      Products In Cart
                </label>
                <input type="text" id="medicine" name="Title" value="<?php echo $_REQUEST['Title']?>">
                </div>
                </div>




            <label>
            <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
            </label>
            <input type="submit" value="Continue to checkout" class="btn">

            
        </form>
        </div>
    </div>

    <!--
    <div class="col-25">
        <div class="container">
        <h4>Cart</h4>
        <td>Products<?php echo $_REQUEST['Title']?></td>

        <a style="font-weight:bold" value="<?php echo $_REQUEST['price']?>">Total Amount- <?php echo $_REQUEST['price']?>  /-</a>
        <p>Total Amount <input type="text" class="form-control" name="price" value="<?php echo $_REQUEST['price']?>" /></p>
        </div>
    </div>
    </div>
-->
</body>
</html>