<?php
require_once"dbconfig.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@900&display=swap" rel="stylesheet">

     <link href="style.css" rel="stylesheet">

    <link href="css/responsive/responsive.css" rel="stylesheet">
<script src="jquery.min.js"></script>
	<script>  
 $(document).ready(function(){  
      $('#country').keyup(function(){  
           var query = $(this).val();
aler(query);		   
           if(query != '')  
           {  
                $.ajax({  
                     url:"searchinput.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#countryList').fadeIn();  
                          $('#countryList').html(data);  
                          
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#country').val($(this).text());  
           $('#countryList').fadeOut();  
      }); 

$('.navbar-light .dmenu').hover(function () {
        $(this).find('.sm-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.sm-menu').first().stop(true, true).slideUp(105)
    });	  
 });  
 </script>  
</head>

<body>
    
   <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:35px;"href="index.php">MEDIKART</a>
                       
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                       
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php"><span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                    
                                </li>
                                
                            </ul>
                             <div class="dorne-signin-btn">
							   <?php
							   if(isset($_SESSION['login']))
							   {
								   ?><a class="nav-link" style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:20px;" href="index.php">Home <span class="sr-only">(current)</span></a>
                              
								<a class="nav-link"style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:20px;" href="mycart.php">My Cart</a>
								<a class="nav-link"style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:20px;" href="contact.php">Contact Us</a>
                              
                                	<a class="nav-link"style="font-weight:bold;
                                   font-size:20px;" href="logout.php">Logout</a>
								   
								   <?php
							   }
								   else
								   {
									   ?>
									   <a style="font-weight:bold;
                                   font-size:20px;"href="ragister.php">Sign in  or Register</a>
								<a class="nav-link" style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:20px;"href="index.php">Home <span class="sr-only">(current)</span></a>
								<a class="nav-link" style="text-shadow: 2px 2px #000000;font-weight:bold;
                                   font-size:20px;"href="contact.php">Contact Us</a>
                              
								   <?php
								   }
							   
							   ?>
                                
                            </div>
                           
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
     <section class="dorne-welcome-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-2.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-md-6"></br></br>
                    <div class="hero-content"></br></br></br></br></br>
                        
                              <h1 style="text-shadow: 3px 3px #000000;color:white;font-weight:bold;  ">SEARCH YOUR PRODUCT</h1>
                        
                    </div>
                    
<div class="container-fluid">
<div class="row">
<div class="col-lg-4">
<form class="form-inline" method="post" action="search_view.php">  

  
  <div class="form-group ">
    <input type="text" class="form-control" name= "country" id="country"  placeholder="Type here...">
  </div>
  </div><div class="col-lg-4">

  <div class="form-group ">
<select class="form-control" name="category">
<option>Select</option>
<option value="HOMEOPATHY">ALLOPATHIC MEDICINES</option>
<option value="VITAMINSSUPPLEMENTS">VITAMINS & SUPPLEMENTS</option>
<option value="AYURVEDA">AYURVEDA</option>
<option value="HEALTHFOOdDRINKS">HEALTH FOOD & DRINKS</option>
<option value="HEALTHCAREDEVICES">HEALTHCARE DEVICES</option>
<option value="SKINCARE">SKIN CARE</option>
</select>




</select>     
	 </div>
  </div>
   
<div class="col-lg-4">
  <button type="submit" name="onsearch" id="search_click" class="btn btn-success ">Search</button></div>
</form>	
		 	
</div>
</div>
<div id="countryList" style="background-color:yellow"></div>	
                </div>
            </div>
        </div>
       
        
    </section>
    
    
   
    <section class="dorne-features-destinations-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading dark text-center">
                        <span></span>
                        <h3 style=" font-weight:bold;">OUR MEDICINE COLLECTION</h3>
                        <p>Best Items</p>
                    </div>
                </div>
            </div>
<h4 style="background-color:#362175;color:white;text-align:center">ALLOPATHIC MEDICINES</h4>
                    
            <div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                      
					 <?php
					 $result=select("select * from items where category='HOMEOPATHY'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
                        <div class="single-features-area">
                            <a href="view_detail.php?id=<?=$elecid?>"><img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                            
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5></br>
								     </div>
                                
								
                            </div></a>
                        </div>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			<h4 style="background-color:#362175;color:white;text-align:center">VITAMINS & SUPPLEMENTS</h4>
 
			<div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                     
					 <?php
					 $result=select("select * from items where category='VITAMINSSUPPLEMENTS'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
                        <a href="view_detail.php?id=<?=$elecid?>"><div class="single-features-area">
                            <img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                            
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5>
                                    </div>
                                
								
                            </div>
                        </div></a>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			<h4 style="background-color:#362175;color:white;text-align:center">AYURVEDA</h4>
 
			<div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                     
					 <?php
					 $result=select("select * from items where category='AYURVEDA'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
                        <a href="view_detail.php?id=<?=$elecid?>"><div class="single-features-area">
                            <img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                           
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5>
                                    </div>
                                
								
                                     
                            </div>
                        </div></a>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			<h4 style="background-color:#362175;color:white;text-align:center">HEALTH FOOD & DRINKS</h4>
 
			<div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                     
					 <?php
					 $result=select("select * from items where category='HEALTHFOOdDRINKS'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
                        <a href="view_detail.php?id=<?=$elecid?>"><div class="single-features-area">
                            <img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                           
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5>
                                    </div>
                                
                                     
                            </div>
                        </div></a>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			<h4 style="background-color:#362175;color:white;text-align:center">HEALTHCARE DEVICES</h4>
 
			<div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                     
					 <?php
					 $result=select("select * from items where category='HEALTHCAREDEVICES'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
					    <a href="view_detail.php?id=<?=$elecid?>"><div class="single-features-area">
                            <img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                          
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5>
                                    </div>
                                
							
                                     
                            </div>
                        </div></a>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			<h4 style="background-color:#362175;color:white;text-align:center">SKINCARE</h4>
 
			<div class="row">
                <div class="col-12">
                    <div class="features-slides owl-carousel">
                     
					 <?php
					 $result=select("select * from items where category='SKINCARE'");
					 while($r=mysqli_fetch_array($result))
					 {
						 extract($r);
					 ?>
                        <a href="view_detail.php?id=<?=$elecid?>"><div class="single-features-area">
                            <img src="admin/images/<?=$image?>" style="height:200px;width:400px">
                            
                            <div class="price-start">
                                </div>
                            <div class="feature-content d-flex align-items-center justify-content-between" style="height:150px">
                                <div class="feature-title">
								 <p><?=$Title?></p>
                               
                                   <h5>₹<?=$price?>/-</h5>
                                    </div>
                              
                            </div>
                        </div></a>
						<?php
					 }
						?>
                        
                        
                    </div>
                </div>
            </div></br></br>
			
        </div>
    </section>
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <script src="js/bootstrap/popper.min.js"></script>    
    <script src="js/bootstrap/bootstrap.min.js"></script>    
    <script src="js/others/plugins.js"></script>
    <script src="js/active.js"></script>

<!--
Backend :- Suyash Malekar, Rohit Utekar. 
Front End:- Mansi Gawade, Sanika Gurde.
-->
   
</body>

</html>