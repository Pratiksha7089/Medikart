<?php
require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
	
}
else
{
	header("location:ragister.php");
}

$result=select("SELECT * FROM cart INNER JOIN items ON cart.elecid = items.elecid WHERE userid='".$_SESSION['userid']."'");
$result1=select("SELECT sum(price) FROM cart INNER JOIN items ON cart.elecid = items.elecid WHERE userid='".$_SESSION['userid']."'");
$result2=select("select * from user WHERE userid='".$_SESSION['userid']."'");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@900&display=swap" rel="stylesheet">

    <link href="style.css" rel="stylesheet">

    
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    


 
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
					 <a class="navbar-brand" style="font-weight:bold;
                     font-size:30px;color:white;font-weight:bold;"href="index.php">MEDIKART</a>
                       
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                       
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"> <span class="sr-only">(current)</span></a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="mycart.php"></a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="logout.php"></a>
                                </li>
                            </ul>
                            
                           
						       <div class="dorne-signin-btn">
							   <?php
							   if(isset($_SESSION['login']))
							   {
								   ?><a class="nav-link"  style="font-weight:bold;
                                   font-size:20px;" href="index.php">Home <span class="sr-only">(current)</span></a>
                              
								<a class="nav-link" style="font-weight:bold;
                                   font-size:20px;" href="mycart.php">My Cart</a>
								<a class="nav-link"style="font-weight:bold;
                                   font-size:20px;" href="contact.php">Contact Us</a>
                              
                                	<a class="nav-link"style="font-weight:bold;
                                   font-size:20px;" href="logout.php">Logout</a>
								   
								   <?php
							   }
								   else
								   {
									   ?>
									   <a style="font-weight:bold;
                                   font-size:20px;"href="rajister.php">Sign in  or Register</a>
								<a class="nav-link" style="font-weight:bold;
                                   font-size:20px;"href="index.php">Home <span class="sr-only">(current)</span></a>
								
								   <?php
								   }
							   
							   ?>
                                
                            </div>
                           
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-4.jpg)"></div>
	</br>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-1 text-center"></div>
        <div class="col-lg-10 text-center">
		
          <div class="alert alert-light" role="alert">
  <p style="color:red;font-weight:bold;font-size:30px;">My Cart Details<p>
</div>
        </div>
		 <div class="col-lg-1 text-center"></div>
       
	   
	   
      </div>
	  <div class="row">
	  <div class="col-lg-1"></div>
	  <div class="col-lg-10">
<div class="card text-center">
  
  <table class="table">
  <tr style="font-weight:bold">
  <td>
S.No.
</td>
<td>image
</td>
<td>
Medicine name
</td>
<td>
Price
</td>
<td>
Remove
</td>
  </tr>
  <?php
  $n=1;
  while($p=mysqli_fetch_array($result))
  {extract($p); 
  ?>
  <tr>
  <td><?=$n?>.</td>
  <td><img src="admin/images/<?=$image?>" style="height:80px"></td>
  <td><?=ucwords($Title)?></td>
  <td>₹<?=$price?>/-</td>
  <td><a href="myphp.php?dele=yes&id=<?=$cartid?>">
          <span class="btn btn-danger">X</span>
        </a></td>
  <?php
	 $n++;
	 }
  ?>
  </tr>
</table>
  <div class="card-footer text-muted">
  <?php
  while($t=mysqli_fetch_array($result1))
  {extract($t);
  ?>
    
     <a href="mycart.php" class="btn btn-danger" style="font-weight:bold">Total Price- <?=$t[0]?>  /-</a>
	 
          <a href="checkout2.php?price=<?=$t[0]?> &amp; Title=<?=$Title?>"><span class="btn btn-success">Buy</span></a>
     	 <?php
  }
	 ?>
  </div>
  <div class="card-footer text-muted">
     <a href="index.php" class="btn btn-primary">Continue shopping</a>
  </div>
</div>	  
	  
	  </div></div>
	

    <script src="js/jquery/jquery-2.2.4.min.js"></script>   
    <script src="js/bootstrap/popper.min.js"></script>    
    <script src="js/bootstrap/bootstrap.min.js"></script>    
    <script src="js/others/plugins.js"></script>  
    <script src="js/active.js"></script>
</body>
</html>