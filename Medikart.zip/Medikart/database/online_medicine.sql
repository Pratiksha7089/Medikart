-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2022 at 03:41 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_medicine`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `image` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `mobile`, `email`, `password`, `image`) VALUES
(1, 'admin', '9999999999', 'admin@gmail.com', 'password', 'admin2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartid` int(6) NOT NULL,
  `Title` varchar(400) NOT NULL,
  `elecid` int(6) NOT NULL,
  `userid` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartid`, `Title`, `elecid`, `userid`) VALUES
(48, 'Hydrate+ Face Wash', 84, 8),
(60, 'Dabur Chyawanprash ', 13, 4),
(62, 'Dabur Chyawanprash ', 13, 4),
(64, 'Benadryl cough syrup', 35, 9);

-- --------------------------------------------------------

--
-- Table structure for table `contactdata`
--

CREATE TABLE `contactdata` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(55) NOT NULL,
  `message` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactdata`
--

INSERT INTO `contactdata` (`firstname`, `lastname`, `phone`, `email`, `message`, `id`) VALUES
('Suyash', 'Malekar', '7666120450', 'suyashmalekar2003@gmail.com', 'Very Nice service', 2),
('Sanika', 'Gurde', '8855885566', 'sanikagurde@gmail.com', 'Very Nice service provided', 10),
('Suyash', 'Malekar', '7666120450', 'suyashmalekar2003@gmail.com', 'i need ors powder', 11);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `elecid` int(9) NOT NULL,
  `Title` varchar(400) NOT NULL,
  `category` varchar(40) NOT NULL,
  `elec_rating` int(3) NOT NULL,
  `image` varchar(90) NOT NULL,
  `discription` varchar(1000) NOT NULL,
  `price` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`elecid`, `Title`, `category`, `elec_rating`, `image`, `discription`, `price`) VALUES
(8, 'NutrineLife Multivitamin Supplement', 'VITAMINSSUPPLEMENTS', 5, '61MS9JgMncL._SL1450_.jpg', 'NutrineLife Multivitamin with Multi Mineral for Women have Vitamins A, C, D, E, B6, B12 as well as , Folic Acid, Biotin, Lutein, Essential Minerals, Alpha.', '963'),
(9, 'Sapien Body ', 'VITAMINSSUPPLEMENTS', 5, '51LuEFQNgxL._SL1050_.jpg', 'Sapien Body Total B Capsule helps to boost the metabolism, energy and improves the functioning of the brain. It is made with the 8 essential vitamins that are vital for mind and body.', '1500'),
(10, 'Purayati Multivitamin Tablets ', 'VITAMINSSUPPLEMENTS', 5, '51b1j63plTL._SL1024_.jpg', 'Rich Nutrient Profile: To provide energy in a sustained fashion, Purayati multivitamins for men encapsulates 23 essential nutrients.', '70'),
(12, 'Zandu Kesari Jivan ', 'AYURVEDA', 5, '81J8thIJSnL._SL1500_.jpg', 'Zandu Kesari Jivan gives you power & helps build endurance while keeping you energetic, throughout the day. This revitalizer, enriched with saffron and pearl, provides a healthy dose of calcium thereby strengthening the bones. Regular use improves immunity.                       \r\n', '521'),
(13, 'Dabur Chyawanprash ', 'AYURVEDA', 5, '61EhUbk23wL._SL1200_.jpg', 'Ayurvedic Dabur Chyawanprash is an excellent source of health supplements to boost immunity. It is a delicious jam formulated with Ayurvedic herbs to prevent and cure various infections that shoulder up our bodies. The amalgamation of 41 herbal ingredients helps in restoring health, vitality and youthfulness', '320'),
(14, 'Himalaya Confido Tablets ', 'AYURVEDA', 5, '61Cim3CxGOL._SL1000_.jpg', 'Himalaya Confido Capsule is a time-tested formula made with ayurvedic ingredients that enhance sexual drive in men and also help manage the sexual..', '300'),
(15, 'Himalaya Wellness Pure Herbs Ashvagandha', 'AYURVEDA', 5, '71WufUyijvL._SL1500_.jpg', 'Himalaya Pure Herb Ashvagandha Tablet acts as a rejuvenating tonic. It is known for its immunomodulatory and inflammation-reducing properties..', '500'),
(16, 'Merck SevenSeas ', 'HEALTHFOOdDRINKS', 5, '51hFiMx0lQL.jpg', 'dha helps brain development vitamins a and d support eyes, bones and teeth omega 3 fatty acids and vitamins support immunity the foundation of a healthy life begins with good nutrition.', '400'),
(17, 'Herbalife Afresh Energy Drink', 'HEALTHFOOdDRINKS', 5, '51tCiPwbkjL._SL1001_.jpg', 'Herbalife afresh organic herbal beverage tea instant energy health drink mix for weight loss Great value and energy quick boost powder makes you fit and healthy Just like roctane\r\n', '50'),
(18, 'Protinex Vanilla Delight ', 'HEALTHFOOdDRINKS', 5, '81cWOEqymLL._SL1500_.jpg', 'Has High Protein Content - 32 G Protein Per 100 G, Contains Milk And Soy Proteins, Low In Fat & Fortified With Vitamins And Minerals In Delicious Chocolate Flavour. 100% Veg\r\n', '420'),
(19, 'Neuherbs Organic Green Coffee Beans', 'HEALTHFOOdDRINKS', 5, '61D4KsVelyL._SL1500_.jpg', 'Neuherbs Green Coffee beans are raw, natural, untreated coffee grains that are GMP & ISO Certified and are without added Chemicals. Neuherbs Experts provide free counseling to make you Fit as a fiddle by guiding you not only with the product but also by providing you guidance over daily diet plans.', '40'),
(20, 'Wow Biotin Maximum Strength Veg Capsule ', 'HEALTHFOOdDRINKS', 5, '719yVsL8HEL._SL1500_.jpg', 'WOW Life Science Biotin is a premium dietary supplement with Biotin - also called Vitamin B7 and Vitamin H- to help improve health of hair, nails and skin.', '360'),
(21, 'c-Rest Neck Massager Pillow', 'HEALTHCAREDEVICES', 5, '612OHFmRX4L._SL1000_.jpg', 'C-Rest Neck Massager Pillow Portable Cervical Spine Massage Tools for Relase Stress, Neck and Shoulder Pain, Improve Posture, Release Muscle Tension.', '500'),
(22, 'Dr Physio (USA) Electric Heat ', 'HEALTHCAREDEVICES', 5, '81PfC3qz7WL._SL1500_.jpg', 'You can use this full-body massager on your back, calves, shoulders, neck, foot, and on other body parts. It helps to relieve tension from your muscles and keeps your body fit and relaxed. This massager provides deep-kneading as well as heated massage with eight different kneading nodes to relax your body.', '1000'),
(23, 'Flamingo HC 1002 Orthopaedic ', 'HEALTHCAREDEVICES', 5, '41lN8XJRKDL.jpg', 'Flamingo orthopaedic heat belt is strongly recommended by physicians and doctors for quick and lasting relief from spinal disorders, joint and muscular pains, abscesses, boils etc. Even women related pains (under the strict guidance of a doctor). It is light and flexible, and above all safe as it comes with two thermostats.', '300'),
(24, 'Equinox Hot Water Bottle ', 'HEALTHCAREDEVICES', 5, '71Vn0S5iivL._SL1200_.jpg', 'Equinox Hot Water Bottle (EQ-HT-01 C) is a very useful and multipurpose product. Heat therapy can help relieve pain in the affected region and bring relief.', '900'),
(25, 'Thermocare Gel Electric Warm', 'HEALTHCAREDEVICES', 5, '71iJO1kqqdL._SL1500_.jpg', 'Eliminate muscle fatigue, improve blood circulation\r\nHeating pad is the technique for traditional hot water bottle\r\nSimple to use and easy to carry, variation colours available\r\nThis generation technology, safe and reliable use', '1200'),
(26, 'Vaseline Intensive', 'SKINCARE', 5, '51R-KubhnlL._SL1000_.jpg', 'Vaseline intensive care deep restore body lotion is designed to penetrate the outermost layer of the skin to help heal dry skin for long periods of time', '300'),
(27, 'Nivea Nourishing Lotion Body Milk with D', 'SKINCARE', 5, '71h3tcA8VUL._SL1500_.jpg', 'Enriched with Natural Minerals and Moisturisers, NIVEA Nourishing Body Milk works deep within the skin repairing dryness layer by layer & stimulating.', '400'),
(28, 'Parachute Advansed Body Lotion ', 'SKINCARE', 5, '61Oc9yvHdPL._SL1500_.jpg', 'It moisturizes and soothes skin from within, restoring lost moisture and helps in repair of dry and irritated skin. The entire range of Parachute Advansed Body.', '450'),
(29, 'Lakme Absolute Perfect Radiance Skin', 'SKINCARE', 5, '51amgXm0IwL._SL1000_.jpg', 'Moisture rich yet so ultra light this crème melts into your skin with a silky feel. This formulation gently polishes your skin to reveal that illuminated look.', '260'),
(30, 'Lakme Blush and Glow Strawberry Gel Face', 'SKINCARE', 5, '616pyi18tXL._SL1000_.jpg', 'Formulated by Lakme Salon experts & enriched with goodness of rich strawberry extracts. The face wash has fruit anti-oxidants and beads that cleanse your skin.', '420'),
(32, 'Dolo-650 Tablet 15\'s', 'HOMEOPATHY', 5, 'dolo.jpg', 'Dolo 650 Tablet is a medicine used to relieve pain and reduce fever', '32'),
(33, 'Sinus 77 Tablet', 'HOMEOPATHY', 5, 'sinus77.jpg', ' used to treat the common cold and allergic symptoms like sneezing, watery eyes, or itchy/watery nose and throat.', '29'),
(34, 'Omez D tablet', 'HOMEOPATHY', 5, 'omez.jpg', 'Omez-Dsr Capsule is a prescription medicine used to treat gastroesophageal reflux disease (Acid reflux) and peptic ulcer disease by relieving the symptoms such as heartburn, stomach pain, or irritation. It also neutralizes the acid in the stomach and promotes easy passage of gas to reduce stomach discomfort.', '178'),
(35, 'Benadryl cough syrup', 'HOMEOPATHY', 5, 'benadryl.jpg', 'Benadryl Dry Cough & Nasal Congestion is used to relieve the symptoms of cold and cough such as runny nose, nasal congestion and dry cough.', '106'),
(36, 'Crocin Pain Relief', 'HOMEOPATHY', 5, 'crocin.jpg', 'Crocin Pain Relief provides targeted pain relief. It provides symptomatic relief from mild to moderate pain e.g from headache, migraine, toothache and musculoskeletal pain. Its formula contains clinically proven ingredients paracetamol and caffeine. It acts at the center of pain', '66'),
(37, 'Omega 3 Fish Oil', 'VITAMINSSUPPLEMENTS', 5, 'omega3.jpg', 'Omega-3s are nutrients you get from food (or supplements) that help build and maintain a healthy body.', '799'),
(38, 'Vitamin C Tablets', 'VITAMINSSUPPLEMENTS', 5, 'vitaminc.jpg', 'Vitamin C, also known as ascorbic acid, is necessary for the growth, development and repair of all body tissues.', '179'),
(39, 'Zincovit', 'VITAMINSSUPPLEMENTS', 5, 'zincovit.jpg', 'Zincovit tablet is a nutritional supplement that has a combination of grape seed extract and essential vitamins and minerals. It is used to prevent and treat vitamin and mineral deficiencies, boost immunity, and improve the overall health of an individual.', '85'),
(41, 'Evion Vitamin E', 'VITAMINSSUPPLEMENTS', 5, 'evion.jpg', 'Evion 400 Capsule 10\'s belongs to a class of vitamins used to treat vitamin E deficiency and ataxia (impaired balance) due to various complications or long-term diseases.', '11'),
(42, 'Uprise-D3 60K', 'VITAMINSSUPPLEMENTS', 5, 'D3.JPG', 'Uprise-D3 60K Capsule is used in the treatment of vitamin D deficiency and osteoporosis. It helps the body to absorb calcium', '215'),
(43, 'Himalaya Liv.52 Tablets', 'AYURVEDA', 5, '61sus85P5BL._SL1000_.jpg', 'Himalaya Liv. 52 Ds Syrup has a herbal formulation that helps protect the liver against hepatotoxins. It contains the goodness of chicory and the caper bush which are known to protect the liver from alcohol toxicity and improves liver functioning.', '520'),
(44, 'Ashwagandha Tablets ', 'AYURVEDA', 5, 'ashva.jpg', ' Helps improve immunity and body’s defence against various ailments and infections • Rejuvenates the body and boosts vitality and stamina • Enhances the energy levels • Calms the mind and alleviates anxiety', '150'),
(45, 'KAPIVA DIGESTI CARE JUICE', 'AYURVEDA', 5, 'kapiva.jpg', 'Get long-term relief from acidity and bloating issues. Made from 5 Ayurvedic herbs- Amla, Jeera, Ajwain, Hing, and Dhania to treat the root cause', '450'),
(46, 'Protinex Vanilla Delight - 400 g', 'HEALTHFOOdDRINKS', 5, '81cWOEqymLL._SL1500_.jpg', 'Has High Protein Content - 32 G Protein Per 100 G, Contains Milk And Soy Proteins, Low In Fat & Fortified With Vitamins And Minerals In Delicious Chocolate Flavour. 100% Veg\r\n\r\n ', '420'),
(47, ' Saffola Immuniveda Golden Turmeric Mil', 'HEALTHFOOdDRINKS', 5, 'saff.jpg', 'Saffola Immuniveda Golden Turmeric Milk Mix is an ayurvedic drink mix based on the time tested Haldi doodh recipe. The golden turmeric milk mix is enriched with black pepper, cardomom, cinnamon, making it tasty as well as healthy. This drink contains immunity boosting powers and anti-inflammatory properties that keeps you and your family healthy.', '400'),
(48, 'Real Fruit Power Juice', 'HEALTHFOOdDRINKS', 5, 'real.jpg', 'It is an amazingly made, healthy blend of fresh fruits, packed with much energy.\r\nIts great taste is very filling and full of health benefits. So, relish your meals with the Réal Fruit Power mixed fruit.\r\nThe product has no added preservatives.\r\n\r\n\r\n', '100'),
(49, 'Lymphomyosot Rx Injectables', 'HOMEOPATHY', 3, 'lym.JPG', 'Lymphomyosot x® Injection Solution is a homeopathic drug product indicated for the improvement of lymphatic drainage, the non-specific immune defense, and conditions such as benign hypertrophy of lymphnodes, chronic tonsillitis, tonsillar hypertrophy and lymphatic edema', '80'),
(50, 'Serotonin Dopamine Liquescence', 'HOMEOPATHY', 2, 'amine.JPG', 'For the temporary relief of anxiousness‚ restlessness‚ feelings of sadness‚ excessive worry‚ poor concentration‚ or stress', '320'),
(51, 'T-Relief Pain Gel', 'HOMEOPATHY', 5, 't-relife.JPG', 'T-Relief = Total Relief. Relieves muscle, joint and nerve pains. Great for Sore backs, painful knees, sciatica, arthritis pain, muscle soreness, neck pain', '39'),
(53, 'Himalayan Organics', 'AYURVEDA', 5, 'AYURVEDA2.jpg', 'Himalayan Organics Plant Based Brain Booster Supplement with Ginkgo Biloba & Brahmi | Boost concentration & Learning Activities | 60 Veg Capsules', '499'),
(54, 'Immunity Booster', 'AYURVEDA', 5, 'AYURVEDA1.jpg', 'Saffola ImmuniVeda Golden Turmeric Milk Mix is an instant mix based on the time-tested immunity-boosting recipe \"Haldi-Doodh\". Each serve of this mix has the goodness of 2 spoons of Turmeric, which helps improving immunity and manage inflammation and is a natural source of anti-oxidants. This healthy drink is enriched with Cardamom, Cinnamon and Black Pepper are tasty as well.', '359'),
(55, 'Anti Pigmentation Tablets', 'AYURVEDA', 5, 'AYURVEDA4.jpg', 'Anti Pigmentation Tablets\r\nTurmeric Curcumin Ayurvedic Formula for Even Skin Tone', '123'),
(63, 'Biotin Hair Gummies', 'VITAMINSSUPPLEMENTS', 5, 'vitamins1.jpg', 'NOURISH Biotin Hair Gummies contain Biotin, Zinc and Multivitamins to improve hair health. Regular intake of these hair vitamins helps improve texture, density and strength of hair.', '59'),
(64, 'Hair Vitamin', 'VITAMINSSUPPLEMENTS', 5, 'vitamins2.jpg', 'A non-sugary mutivitamin for hair with a combination of all essential vitamins and minerals that will boost your hair health. These DHT blocker vitamins consists of pumpkin seed extract which reverses the effect of DHT on hair follicles.', '199'),
(65, 'KUMKUMADI TAILAM MAGICAL BEAUTY ', 'AYURVEDA', 5, 'AYURVEDAnew.jpg', 'Kumkumadi tailam or Kumkumadi oil is a marvellous herbal concoction that serves as a magical cure for protecting the skin and treating different skin problems. This oil, which can also be used as a moisturiser, is suitable for nearly all forms of skin, especially for sensitive or dry, flaky skin.', '1190'),
(66, 'Anti Acne Tablets ', 'AYURVEDA', 5, 'AYURVEDAnew2.jpg', 'For Pus Filled Pimples, Marks, Scars', '350'),
(67, 'Manna  Health Mix', 'HEALTHFOOdDRINKS', 5, 'health.jpg', 'Manna is a well-known brand that deals with several health mixes and other products that can be used by patients who suffer from diabetes and other lifestyle ailments. The health mix by Manna is a porridge based product that offers an excellent nutritional mix for the entire family.', '359'),
(68, 'Superfood Greens & Herbs', 'HEALTHFOOdDRINKS', 5, 'health2.jpg', 'OZiva Superfood Greens and Herbs is one of the finest products for a diet. I have felt the changes in a couple of weeks. It is an all-in-one plant protein.', '360'),
(69, 'Ensure Nutritional Powder', 'HEALTHFOOdDRINKS', 5, 'health3.jpg', 'Ensure is scientifically formulated to provide complete & balanced nutrition containing 32 nutrients. Ensure, when mixed with Water makes a drink that provides complete & balanced nutrition for use as a meal replacement, or as a supplement to increase caloric or protein intake, or to maintain good Nutrition.', '56'),
(70, 'Pediasure Nutritional Powder', 'HEALTHFOOdDRINKS', 5, 'pedia.jpg', 'Pediasure premium chocolate is a most important moms care product and a complete and balanced nutrition diet for your small choosy eater. It is a strong blend of prebiotics and probiotics that make stronger your childs immunity.', '599'),
(72, 'Beurer Ft 09/1 Clinical Thermometer', 'HEALTHCAREDEVICES', 5, 'healthcare1.jpg', 'Fever measurement made easy! The clinical thermometer with contact-measurement technology is easy to use and waterproof', '299'),
(73, 'Pharmeasy All-In -One Vaporizer', 'HEALTHCAREDEVICES', 5, 'healthcare2.jpg', 'PharmEasy All In One Vaporizer is made up of good quality copper wire to generate dense steam and contains 3 attachments that can be used for multiple purposes. This device can help relieve the symptoms of a common cold or the flu. It can decongest the lungs, clear away the sinuses, and aid in easier breathing and better sleep. PharmEasy All In One Vaporizer can be utilized for steam therapy that can ease headaches and sinus pain.', '650'),
(74, 'Pharmeasy Orthopaedic Electric Heat Belt - Extra Large', 'HEALTHCAREDEVICES', 5, 'healthcare3.jpg', 'Back pain, neck pain, or pain in your joints are quite common and could occur due to a number of reasons- injury, muscle strain, bad posture, or during periods of menstruation. Whatever be the cause, you will be laid low by body pain unless you find ways to relieve the ache and discomfort.', '500'),
(75, 'Vega Go - Lite 1400 Hair Dryer - Vhdh-19', 'HEALTHCAREDEVICES', 5, 'healthcare4.jpg', 'Flaunt your gorgeous hair everywhere you go with Vega Go Lite 1400W hair dryer. This dryer comes with 2 heat settings-low heat setting for perfect gentle drying of slightly wet hair and high heat setting for fast drying of wet and thick hair. This compact dryer comes with a convenient foldable handle makes it easy to pack, store and carry. Cute is so clichéd. Be Shabang Now be all that you want to be with Vega Go Lite 1400 Hair Dryer.', '600'),
(76, 'Liveasy Essentials Copper Bottle ', 'HEALTHCAREDEVICES', 5, 'healthcare5.jpg', 'Ayurvedic Health Benefits', '299'),
(77, 'Easycare (German Tech.) Digital Blood Pressure Monitor', 'HEALTHCAREDEVICES', 5, 'healthcare6.jpg', 'Easy Care EC 9900 Digital Blood Pressure Monitor Arm Automatic is used to measure heart beat with great accuracy and efficiently.', '1299'),
(79, 'Liveasy Essentials Respirometer / Spirometer - Lung Exerciser', 'HEALTHCAREDEVICES', 5, 'healthcare7.jpg', 'Breathing efficiently is associated with many health benefits such as mental clarity, reduced stress, efficient sleep, improved immune function and proper digestion. The modern times have made us realize the importance of healthy lungs and thus there is a need to improve our lung capacity.', '760'),
(80, 'Cetaphil Gentle Skin Cleanser', 'SKINCARE', 5, 'skiin.jpg', 'cleanes your face to get rid of the daily toxins.', '506'),
(82, 'mamaearth Vitamin C Night Cream ', 'SKINCARE', 5, 'skiin3.jpg', 'mamaearth Vitamin C Night Cream For Women with Vitamin C & Gotu Kola for Skin Illumination (50g)', '210'),
(84, 'Hydrate+ Face Wash', 'SKINCARE', 5, 'skiin5.jpg', 'Deep Cleansing & Hydration with Coconut water & Hyaluronic Acid', '200'),
(85, 'Deep Cleansing & Hydration with Coconut water & Hyaluronic Acid', 'SKINCARE', 5, 'final.jpg', 'Jovees Advanced 7 in 1 Skin Boosting Cream for Men is formulated after an extensive research followed by clinical tests. Enriched with naturally derived plant extracts this skin boosting cream helps brighten the skin, lighten discoloration, smoothes fine lines.', '333'),
(87, 'sanitizer', 'SKINCARE', 5, 'skinC.jpg', 'sanitizer is use for cleaing hands and priventing from germs.', '65'),
(88, 'Crocin 650', 'HOMEOPATHY', 5, 'crocin 650.jpg', 'Crocin Advance Tablet is a drug that is used fever control.', '55'),
(89, 'Paracetamol', 'HOMEOPATHY', 5, 'para.jpg', 'Paracetamol is a common painkiller used to treat aches and pain. It can also be used to reduce a high temperature. ', '50'),
(90, 'Adulsa Cough Syrup', 'HOMEOPATHY', 5, 'adulsa.jpg', 'Adulsa Cough Syrup is an Ayurvedic cough syrup which helps in relieving dry and wet cough.', '65'),
(91, 'Cetirizine Tablet', 'HOMEOPATHY', 5, 'citrizen.jpg', 'Cetirizine is an antihistamine used to relieve allergy symptoms such as watery eyes, runny nose, itching eyes/nose, sneezing, hives, and itching.', '59'),
(92, 'Gloves', 'SKINCARE', 5, 'gloves.jpg', 'Gloves protect and comfort hands against cold or heat, damage by friction, abrasion or chemicals, and disease; or in turn to provide a guard for what a bare hand should not touch.', '40'),
(93, 'Mask', 'SKINCARE', 5, 'mask.jpg', 'Masks should be used as part of a comprehensive strategy of measures to suppress transmission and save lives; the use of a mask alone is not sufficient to provide an adequate level of protection against COVID-19.', '50');

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `id` int(9) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `address` varchar(300) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `Title` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`id`, `name`, `email`, `mobile`, `address`, `amount`, `Title`) VALUES
(1, 'Suyash Malekar', 'suyashmalekar2003@gmail.com', '7666120450', 'Sawitri Sadan, Near Tahsil Office, Mangaon(402104).', '207', 'Omez D tablet'),
(2, 'Amit S. Sathe', 'amitsathe@gmail.com', '8899665577', 'Anand Villa, S.V. Road, Near Mangaon Bus Stand, Mangaon', '399', 'Sinus-77 tab,\r\nDabur Chavanprash-1kg, \r\nHerbalife Afresh Energy Drink'),
(3, 'Rohit Utekar', 'rohit@gmail.com', '9985761245', 'Rohit Nivas, Nizampur Road, Mangaon(402104).', '900', 'Equinox Hot Water Bottle with Cover.'),
(4, 'Purvesh Malekar', 'purvesh@gmail.com', '9975875984', '2/4, Twin Bunglow, Nirman Residency, Near Bhate Library, Mangaon(402104)', '285', 'Vitamin C Tablets, Benadryl Cough Syrup'),
(5, 'Anish M. Sheth', 'anishsheth@gmail.com', '8798575867', 'Krushna Kunj, Shivaji Nagar, Near Tirupati mandir, Mangaon(402109).', '2063', 'Himalayan Organics, Easycare (German Tech.) Digital Blood Pressure Monitor, hydrate+ facewash, Sanitizer.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `mobile`, `email`, `password`) VALUES
(3, 'Suyash  Rajendra Malekar', '1234123412', 'suyashmalekar2003@gmail.com', 'suyash'),
(4, 'abcd@gmail.com', '******0450', 'abcd@gmail.com', '123456'),
(5, 'rohit', '1234567891', 'rohit@gmail.com', '1234'),
(6, 'Yash Kapure', '9898989898', 'ypkapure74@gmail.com', 'yash'),
(7, 'xyz', '+917666120450', 'suyashmalekar2003@gmail.com', '123456'),
(8, 'Purvesh Malekar', '9975875984', 'purvesh@gmail.com', 'purvesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartid`);

--
-- Indexes for table `contactdata`
--
ALTER TABLE `contactdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`elecid`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartid` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `contactdata`
--
ALTER TABLE `contactdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `elecid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
