
<?php

$name = $_POST["name"];
$email = $_POST["email"];
$mobile = $_POST["mobile"];
$address = $_POST["address"];
$amount = $_POST["amount"];
$Title = $_POST["Title"];


$host = "localhost";
$dbname = "online_medicine";
$username = "root";
$password = "";
        
$conn = mysqli_connect($host,
						$username,
						$password,$dbname);
        
if (mysqli_connect_errno()) {
    die("Connection error: " . mysqli_connect_error());
}           
       

$query = "INSERT INTO `order1`(`name`, `email`, `mobile`, `address`, `amount`, `Title`) 
		  VALUES (?, ?, ?, ?, ?, ?)";

$stmt = mysqli_stmt_init($conn);

if ( ! mysqli_stmt_prepare($stmt, $query)) {
 
    die(mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ssisis",
						$name,
						$email,
						$mobile,
						$address,
						$amount,
						$Title);

mysqli_stmt_execute($stmt);

function redirect($url, $statusCode = 303)
{
   header('Location: ' . $url, true, $statusCode);
   die();
}

Redirect('https://rzp.io/l/xyGyKB9V', false);

echo "Record saved.";
