<?php

$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$message = $_POST["message"];


$host = "localhost";
$dbname = "online_medicine";
$username = "root";
$password = "";
        
$conn = mysqli_connect($host,
						$username,
						$password,$dbname);
        
if (mysqli_connect_errno()) {
    die("Connection error: " . mysqli_connect_error());
} 

$query = "INSERT INTO `contactdata`(`firstname`, `lastname`, `phone`, `email`, `message`) VALUES ('".$firstname."','".$lastname."',".$phone.",'".$email."','".$message."')";

$stmt = mysqli_stmt_init($conn);

if ( ! mysqli_stmt_prepare($stmt, $query)) {
 
    die(mysqli_error($conn));
}

mysqli_stmt_execute($stmt);

echo('Thank You For Contacting Us');

function redirect($url, $statusCode = 303)
{
   header('Location: ' . $url, true, $statusCode);
   die();
}

Redirect('index.php', false);


		



?>

