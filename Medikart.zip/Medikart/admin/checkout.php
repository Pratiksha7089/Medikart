
<?php


$host = "localhost";
$dbname = "online_medicine";
$username = "root";
$password = "";
        
$conn = mysqli_connect($host,
						$username,
						$password,$dbname);
        
?>