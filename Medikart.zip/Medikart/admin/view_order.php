<?php 
require_once('checkout.php');

$result=mysqli_query($conn,"select * from order1");

?> 

<!DOCTYPE html> 
<html> 
	<head> 
        
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@900&display=swap" rel="stylesheet">
      

	</head> 
	<body> 
	<table align="center" border="2px" style=" background-color:; margin-top: 25px; text-align:center;  width:1500px; line-height:60px;"> 
	<tr> 
		<th colspan="7" style=" background-color:#03fcd3;" text-align="center"><h1>ORDERS</h1></th> 
		</tr> 
			  <th> ID </th> 
			  <th> Name </th> 
			  <th> Email </th> 
			  <th> Mobile No.</th>
              <th > Address </th> 
              <th style="  width:300px; "> Product </th>
              <th style="  width:80px; "> Amount Paid</th>
              
              
			  
		</tr> 
		
        <?php 
        if(!$result){
            die(mysqli_error($conn));
        }
        
        // Check is result set le grater then 0
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_array($result)){
                ?>

                <tr> 
                    <td><?php echo $row['id']; ?></td> 
                    <td><?php echo $row['name']; ?></td> 
                    <td><?php echo $row['email']; ?></td> 
                    <td><?php echo $row['mobile']; ?></td>
                    <td><?php echo $row['address']; ?></td> 
                    <td><?php echo $row['Title']; ?></td>
                    <td >₹<?php echo $row['amount']; ?></td> 
                    
                </tr> 

                  <?php
            }
        }
        
        ?>
		
	
        


	</table> 
	</body> 
	</html>